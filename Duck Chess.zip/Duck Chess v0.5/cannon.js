/* facts about cannons:

can move foward or sideways
cannot attack but it can shoot whatever's in front of it









facts about cannon shots: