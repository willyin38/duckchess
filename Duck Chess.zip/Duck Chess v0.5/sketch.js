var ball1;
var ball2;
var ball3;
var ball4;
var duck1;

var infirmary;

var creases = [];

//var infirmary = {
//    red: new BoardSquare(boardWidth - 0.5, boardHeight + 0.5),
//    blue: new BoardSquare(0.5, boardHeight + 0.5)
//}

function setup() {
    createCanvas(CANVAS_WIDTH, CANVAS_HEIGHT);
    background(51);
    stroke(51);
    for(var y = 0; y < boardHeight; y++){
        for(var x = 0; x < boardWidth; x++){
            var terrainType = getTerrain(x, y);
            //checks if loaded terrain type is invalid
            if(terrainType < 0 || terrainType >= terrainTextures.length || terrainType % 1 != 0){
                console.log("Invalid terrain type at grid space " + x + ", " + y);
            }
            dataBoard[y][x] = new BoardSquare(x, y, terrainType);
        }
    }
    dataBoard[boardHeight][0] = new BoardSquare(0.5, boardHeight + 0.5, 3);
    dataBoard[boardHeight][1] = new BoardSquare(boardWidth - 1.5, boardHeight + 0.5, 3);
//    
//    dataBoard[boardHeight][0] = new BoardSquare(0, boardHeight, 3);
//    dataBoard[boardHeight][1] = new BoardSquare(1, boardHeight, 3);
    
    ball1 = new Ball(5, 1, "red");
    ball2 = new Ball(6, 3, "red");
    ball3 = new Ball(0, 0, "red");
    ball4 = new Ball(0, 3, "blue");
    duck1 = new Duck(3, 4, "blue");
    
    ball1.occupy();
    ball2.occupy();
    ball3.occupy();
    ball4.occupy();
    duck1.occupy();
    
    infirmary = {
        blue: dataBoard[boardHeight][0],
        red: dataBoard[boardHeight][1],
    }
    
    creases[0] = new Crease(2.5, 1.5, 0);
    creases[1] = new Crease(3.5, 0.5, 2);
    creases[2] = new Crease(5.5, 0.5, 2);
    creases[3] = new Crease(7.5, 0.5, 2);
    
    creases[0].blaze();
    creases[1].blaze();
    creases[2].blaze();
    creases[3].blaze();
    
}

function draw() {
    background(51);
    hoverGlow();
    
    ball1.update();
    ball2.update();
    ball3.update();
    ball4.update();
    duck1.update();
    
    
    infirmary.red.appear();
    infirmary.blue.appear();
    creases[0].appear();
    creases[1].appear();
    creases[2].appear();
    creases[3].appear();
    
    ball1.appear();
    ball2.appear();
    ball3.appear();
    ball4.appear();
    duck1.appear();
    
    if(!nothingSelected(1) && !nothingSelected(2)) {
        selection.clicked.clear();
        selection.clicked2.clear();
    }
    
    
    
    
    text(selection.clicked.x + ", " + selection.clicked.y, 500, 560);
    text(selection.clicked2.x + ", " + selection.clicked2.y, 780, 560);
}

function mouseClicked() {
    boardSelectionProcedure();
}

function keyPressed() {
    if(!nothingSelected(1)){
        var subject = dataBoard[selection.clicked.y][selection.clicked.x].occupant;
        selection.clicked.clear();
        if(subject != null) {
            if (keyCode == LEFT_ARROW) {
                subject.facing = octoAdd(subject.facing, 2);
                return false;
            } else if (keyCode == RIGHT_ARROW) {
                subject.facing = octoAdd(subject.facing, -2);
                return false;
            }
        }
    }
}

function maintenance() {
    // make sure no more than 1 square at a time has isClicked == true
}






