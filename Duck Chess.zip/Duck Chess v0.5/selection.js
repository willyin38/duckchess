//all about the selection of squares:
var selection = {
    hovered: {
        x: null,
        y: null,
        clear: function(){if(this.x != null && this.y != null){dataBoard[this.y][this.x].isHoveredOver = false;} this.x = null; this.y = null;},
        set: function(x, y){this.x = x; this.y = y; dataBoard[y][x].isHoveredOver = true;}
    },
    
    clicked: {
        x: null, 
        y: null, 
        clear: function(){if(this.x != null && this.y != null){dataBoard[this.y][this.x].isClicked = false;} this.x = null; this.y = null;},
        set: function(x, y){this.x = x; this.y = y; dataBoard[y][x].isClicked = true;}
    },
    
    clicked2: {
        x: null, 
        y: null,
        clear: function(){if(this.x != null && this.y != null){dataBoard[this.y][this.x].isClicked2 = false;} this.x = null; this.y = null;},
        set: function(x, y){this.x = x; this.y = y; dataBoard[y][x].isClicked2 = true;}
    }
};

function boardSelectionProcedure(){
    if(coordIsOnBoard(mouseX, mouseY, "pixel") || coordIsInInfirmary(mouseX, mouseY, "red") || coordIsInInfirmary(mouseX, mouseY, "blue")) {
        if(nothingSelected(1)) {
            selection.clicked.set(selection.hovered.x, selection.hovered.y); //SETS HOVERED SQUARE TO CLICKED SQUARE
        } else {    //if something is selected
            if(!(selection.hovered.x === selection.clicked.x && selection.hovered.y === selection.clicked.y)) { //is different square?
                selection.clicked2.set(selection.hovered.x, selection.hovered.y);
            } else { // what happens if you did actually click the same square again
                selection.clicked.clear(); //makes it so clicking on a clicked square causes an unclick
            }
        }
    } else {
        selection.clicked.clear(); //makes it so clicking off the board undoes your click
    }
}

function hoverGlow() {
    hoverRefresh();
    var mouseGridX = Math.round(pixelToGrid(mouseX));
    var mouseGridY = Math.round(pixelToGrid(mouseY));
    fill(255, 255, 210);
    text(mouseGridX + ", " + mouseGridY, 80, 560);
    if(coordIsOnBoard(mouseGridX, mouseGridY, "grid")) {   // checking that mouse is actually in bounds - CRUCIAL
        
        if(coordIsInCrease(mouseX, mouseY, creases[0])) {
            creases[0].isHoveredOver = true;
        } else if(coordIsInCrease(mouseX, mouseY, creases[1])) {
            creases[1].isHoveredOver = true;
        } else if (coordIsInCrease(mouseX, mouseY, creases[2])) {
            creases[2].isHoveredOver = true;
        } else if (coordIsInCrease(mouseX, mouseY, creases[3])) {
            creases[3].isHoveredOver = true;
        } else {
            selection.hovered.set(mouseGridX, mouseGridY);
        }
        
    } else if(coordIsInInfirmary(mouseX, mouseY, "red")) {
        selection.hovered.set(1, boardHeight);
    } else if(coordIsInInfirmary(mouseX, mouseY, "blue")) {
        selection.hovered.set(0, boardHeight);
    } else {
        selection.hovered.clear();
    }
}

//checks if nothing is selected according to selection obj. @param n = first or second click(takes 1 or 2)
function nothingSelected(n) {
    if(n == 1){
        if(selection.clicked.x == null && selection.clicked.y == null) {
        return true;
        }
    } else if(n == 2){
        if(selection.clicked2.x == null && selection.clicked2.y == null) {
        return true;
        }
    } else {
        console.log('Invalad param "' + n + '" into nothingSelected function')
    }
}

function coordIsInInfirmary(x, y, col) {    //takes pixel inputs only
    var redX = gridToPixel(infirmary.red.gridX);  // in pixels, the x coord of the center of red infirmary
    var redY = gridToPixel(infirmary.red.gridY);
    var blueX = gridToPixel(infirmary.blue.gridX);
    var blueY = gridToPixel(infirmary.blue.gridY);
    
    if(abs(redX - x) <= GRID_SQUARE_WIDTH/2 && abs(redY - y) <= GRID_SQUARE_WIDTH/2 && col == "red") {
        return true;
    } else if(abs(blueX - x) <= GRID_SQUARE_WIDTH/2 && abs(blueY - y) <= GRID_SQUARE_WIDTH/2 && col == "blue") {
        return true;
    } else {
        return false;
    }
}

function coordIsOnBoard(x, y, coordinateSystem) {        //coordinateSystem can be "grid" or "pixel"
    var gridX;
    var gridY;
    if(coordinateSystem === "pixel") {
        gridX = Math.round(pixelToGrid(mouseX));
        gridY = Math.round(pixelToGrid(mouseY));
    } else if(coordinateSystem === "grid") {
        gridX = x;
        gridY = y;
    } else {
        console.log('Error: invalid param "' + coordinateSystem + '" was put into function coordIsOnBoard');
    }
    if((gridX >= 0 && gridX < boardWidth) && (gridY >= 0 && gridY < boardHeight)) {
        return true;
    } else {
        return false;
    }
}

function twoSquaresSelected() {
    if(!nothingSelected(1) && !nothingSelected(2)) {
        return true;
    } else {
        return false;
    }
}

//Unhovers everything
function hoverRefresh() {
    for(var y = 0; y < boardHeight; y++){
        for(var x = 0; x < boardWidth; x++){
            dataBoard[y][x].appear();
            dataBoard[y][x].isHoveredOver = false; //refreshes hover function; makes it so only 1 square is highlighted at a time
        }
    }
    for(var i = 0; i < creases.length; i++){
        creases[i].isHoveredOver = false;
    }
}