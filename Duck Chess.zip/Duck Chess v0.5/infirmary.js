//var infirmary = {
//    red: new BoardSquare(boardWidth - 0.5, boardHeight + 0.5),
//    blue: new BoardSquare(0.5, boardHeight + 0.5)
//}