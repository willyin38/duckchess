var CREASE_LENGTH = 100 + GRID_SQUARE_WIDTH;

var CREASE_WIDTH = 22

function Crease(x, y, orientation) {
    this.gridX = x;
    this.gridY = y;
    this.pixelX = gridToPixel(x);
    this.pixelY = gridToPixel(y);
    this.orientation = orientation;
    this.isHoveredOver = false;
    this.isClicked = false;
    this.isClicked2 = false;
    this.segments = [];
    
    this.blaze = function() {
        if(this.orientation % 4 == 0) { // if east-west
            dataBoard[this.gridY - 0.5][this.gridX - 0.5].crease.s = true;
            dataBoard[this.gridY - 0.5][this.gridX + 0.5].crease.s = true;
            dataBoard[this.gridY + 0.5][this.gridX - 0.5].crease.n = true;
            dataBoard[this.gridY + 0.5][this.gridX + 0.5].crease.n = true;
        } else if(this.orientation % 4 == 2) { // if north-south
            dataBoard[this.gridY - 0.5][this.gridX - 0.5].crease.e = true;
            dataBoard[this.gridY - 0.5][this.gridX + 0.5].crease.w = true;
            dataBoard[this.gridY + 0.5][this.gridX - 0.5].crease.e = true;
            dataBoard[this.gridY + 0.5][this.gridX + 0.5].crease.w = true;
        }
    }
    
    this.appear = function() {
        push();
        noStroke();
        translate(this.pixelX, this.pixelY);
        rotate(octogree(this.orientation));
        rectMode(CENTER);
        fill(100, 100, 75);
        rect(0, 0, 99 + GRID_SQUARE_WIDTH, CREASE_WIDTH);
        if(this.isHoveredOver == true){
            fill(255, 255, 210, 85);
            rect(0, 0, 99 + GRID_SQUARE_WIDTH, CREASE_WIDTH);
        }
        pop();
    }
    
    this.hoverProcedure = function() {
        
    }
    
    
}

function coordIsInCrease(x, y, crease) {
    if(crease.orientation % 4 == 0) {
        if((abs(crease.pixelX - x) < CREASE_LENGTH / 2) && abs(crease.pixelY - y) < CREASE_WIDTH / 2 + 1) {
            return true;
        } else {
            return false;
        }
    } else if(crease.orientation % 4 == 2) {
        if((abs(crease.pixelY - y) < CREASE_LENGTH / 2) && abs(crease.pixelX - x) < CREASE_WIDTH / 2 + 1) {
            return true;
        } else {
            return false;
        }
    } else {
        console.log("Invalid crease: " + crease);
    }
}



