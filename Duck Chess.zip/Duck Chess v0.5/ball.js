/* facts about balls:

no facing direction (or all facing directions)
can move in any direction

can attack in any direction/facing

gets attacked in any direction/facing

can get shot out of a cannon
can kill upon landing provided valid target
*/

function Ball(gridX, gridY, team) {
    this.type = "ball";
    this.team = team;
    this.gridX = gridX;
    this.gridY = gridY;
    this.facing = 0;
    
    this.inInfirmary = false;
    this.inCrease = false;
    
    this.appear = function() {
        var pixelX = gridToPixel(this.gridX);
        var pixelY = gridToPixel(this.gridY);
        if(this.team == "blue") {
            fill(20, 20, 240);
        } else if(this.team == "red") {
            fill(240, 20, 20);
        } else {
            console.log("invalid team color: " + this.team)
        }
        ellipse(pixelX, pixelY, 60, 60);
    }
    
    this.update = function() {
        if(twoSquaresSelected()) {         //regular movement and capture
            if(!this.inInfirmary) {
                if(dataBoard[this.gridY][this.gridX].isClicked) {
                    if(dataBoard[selection.clicked2.y][selection.clicked2.x].occupant != null) { //If a piece is in its way
                        dataBoard[selection.clicked2.y][selection.clicked2.x].occupant.kill();
                    }
                    dataBoard[this.gridY][this.gridX].occupant = null; //setting old square's occupant to null (square side)
                    this.gridX = selection.clicked2.x;                 //updating new coordinates (piece side)
                    this.gridY = selection.clicked2.y;
                }
            } else if(infirmary[this.team].isClicked) {  //if it's in the infirmary
                infirmary[this.team].occupant = null; //setting its infirmary's occupant to null (infirmary side)
                this.inInfirmary = false;   //showing that it's out of the infirmary (piece side)
                this.gridX = selection.clicked2.x;                 //updating new coordinates (piece side)
                this.gridY = selection.clicked2.y;
            }
        }
        this.occupy(); //setting new coordinates' square's occupant to itself (square side)
    }
    
    this.occupy = function() {
        if(!this.inInfirmary){
            dataBoard[this.gridY][this.gridX].occupant = this;
        }
    }
    
    this.kill = function() {
        dataBoard[this.gridY][this.gridX].occupant = null;
        this.gridX = infirmary[this.team].gridX;
        this.gridY = infirmary[this.team].gridY;
        this.inInfirmary = true;
        infirmary[this.team].occupant = this;
        console.log("piece killed");
    }
}