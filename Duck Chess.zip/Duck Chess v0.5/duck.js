/*facts about ducks:

can face only in cardinal directions
can turn 90 degrees
can move forward only

can kill forward only

gets killed from side
gets permakilled from rear
impervious from front

can get shot out of a cannon in any direction
can kill upon landing if facing forward with respect to direction of cannon shot(same facing as the cannon that shot it out)
*/

function Duck(gridX, gridY, team) {
    this.type = "duck";
    this.team = team;
    this.gridX = gridX;
    this.gridY = gridY;
    this.facing = 0;
    
    this.inInfirmary = false;
    this.inCrease = false;
    
    this.appear = function() {
        var pixelX = gridToPixel(this.gridX);
        var pixelY = gridToPixel(this.gridY);
        
        push();
        translate(pixelX, pixelY);
        if(this.inCrease == true) {
            scale(0.4, 0.4);
        }
        rotate(octogree(this.facing));
        
        fill(240, 240, 20);
        ellipse(0, 0, 80, 60);
        ellipse(25, 0, 40, 40);
        if(this.team == "blue") {
            fill(20, 20, 240);
        } else if(this.team == "red") {
            fill(240, 20, 20);
        } else {
            console.log("invalid team color: " + this.team)
        }
        ellipse(-18, 0, 40, 4);
        pop();
    }
    
    this.update = function() {
        if(twoSquaresSelected()) {         //regular movement and capture
            if(!this.inInfirmary) {
                if(dataBoard[this.gridY][this.gridX].isClicked) {
                    if(dataBoard[selection.clicked2.y][selection.clicked2.x].occupant != null) { //If a piece is in its way
                        dataBoard[selection.clicked2.y][selection.clicked2.x].occupant.kill();
                    }
                    dataBoard[this.gridY][this.gridX].occupant = null; //setting old square's occupant to null (square side)
                    this.gridX = selection.clicked2.x;                 //updating new coordinates (piece side)
                    this.gridY = selection.clicked2.y;
                }
            } else if(infirmary[this.team].isClicked) {  //if it's in the infirmary
                infirmary[this.team].occupant = null; //setting its infirmary's occupant to null (infirmary side)
                this.inInfirmary = false;   //showing that it's out of the infirmary (piece side)
                this.gridX = selection.clicked2.x;                 //updating new coordinates (piece side)
                this.gridY = selection.clicked2.y;
            }
        }
        this.occupy(); //setting new coordinates' square's occupant to itself (square side)
    }
    
    this.occupy = function() {
        if(!this.inInfirmary && !this.inCrease){
            dataBoard[this.gridY][this.gridX].occupant = this;
        }
    }
    
    this.kill = function() {
        dataBoard[this.gridY][this.gridX].occupant = null;
        this.gridX = infirmary[this.team].gridX;
        this.gridY = infirmary[this.team].gridY;
        this.inInfirmary = true;
        infirmary[this.team].occupant = this;
        console.log("piece killed");
    }
}