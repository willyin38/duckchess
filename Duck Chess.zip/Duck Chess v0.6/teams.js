var TEAM_SIZE = 4;

var teams = {
    blue: [],
    red: []
};

var teamSpawnerGuide = {
    blue: ["b", "d", "d", "b"],
    
    red:  ["b", "d", "b", "d"]
}

function spawnPieces() {
    for(i = 0; i < TEAM_SIZE; i++) {
        //temp coords are for its coordinates WITHIN ITS SPAWN ZONE
        var tempX = i % 2;
        var tempY = Math.floor(i / 2);
        var gridX = tempX;
        var gridY = tempY + 3;
        
        if(teamSpawnerGuide.blue[i] == "b") {
            teams.blue[i] = new Ball(gridX, gridY, "blue");
        } else if(teamSpawnerGuide.blue[i] == "d") {
            teams.blue[i] = new Duck(gridX, gridY, "blue");
        }
        
        gridX = tempX + 8;
        gridY = tempY;
        
        if(teamSpawnerGuide.red[i] == "b") {
            teams.red[i] = new Ball(gridX, gridY, "red");
        } else if(teamSpawnerGuide.red[i] == "d") {
            teams.red[i] = new Duck(gridX, gridY, "red");
        }
    }
}

function occupyAllPieces() {
    for(i = 0; i < TEAM_SIZE; i++) {
        teams.blue[i].occupy();
        teams.red[i].occupy();
    }
}

function updateAllPieces() {
    for(i = 0; i < TEAM_SIZE; i++) {
        teams.blue[i].update();
        teams.red[i].update();
    }
}

function appearAllPieces() {
    for(i = 0; i < TEAM_SIZE; i++) {
        teams.blue[i].appear();
        teams.red[i].appear();
    }
}