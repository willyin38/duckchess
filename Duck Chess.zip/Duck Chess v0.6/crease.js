var CREASE_LENGTH = 100 + GRID_SQUARE_WIDTH;

var CREASE_WIDTH = 22

function Crease(x, y, orientation) {
    this.gridX = x;
    this.gridY = y;
    this.pixelX = gridToPixel(x);
    this.pixelY = gridToPixel(y);
    this.orientation = orientation;
    this.isHoveredOver = false;
    this.isClicked = false;
    this.isClicked2 = false;
    this.segments = [];
    this.occupant = null;
    
    this.blaze = function() {
        if(this.orientation % 4 == 0) { // if east-west
            dataBoard[this.gridY - 0.5][this.gridX - 0.5].crease.s = true;
            dataBoard[this.gridY - 0.5][this.gridX + 0.5].crease.s = true;
            dataBoard[this.gridY + 0.5][this.gridX - 0.5].crease.n = true;
            dataBoard[this.gridY + 0.5][this.gridX + 0.5].crease.n = true;
        } else if(this.orientation % 4 == 2) { // if north-south
            dataBoard[this.gridY - 0.5][this.gridX - 0.5].crease.e = true;
            dataBoard[this.gridY - 0.5][this.gridX + 0.5].crease.w = true;
            dataBoard[this.gridY + 0.5][this.gridX - 0.5].crease.e = true;
            dataBoard[this.gridY + 0.5][this.gridX + 0.5].crease.w = true;
        }
    }
    
    this.appear = function() {
        push();
        noStroke();
        translate(this.pixelX, this.pixelY);
        rotate(octogree(this.orientation));
        rectMode(CENTER);                     //screen is centered at center of crease, X axis is the long axis of crease, and rectangles are drawn from CENTER
        fill(100, 100, 75);
        rect(0, 0, CREASE_LENGTH - 1, CREASE_WIDTH);
        if(this.isHoveredOver == true){
            fill(255, 255, 210, 85);
            rect(0, 0, CREASE_LENGTH - 1, CREASE_WIDTH);
        }
        if(this.isClicked == true){
            fill(210, 255, 210, 100);
            rect(0, 0, CREASE_LENGTH - 1, CREASE_WIDTH);
        }
        for(i = 0; i < this.segments.length; i++) {
            this.segments[i].appear();
        }
        pop();
    }
    
    this.updateSegments = function() {
        for(i = 0; i < this.segments.length; i++) {
            if(this.segments[i].occupant == null) {
                this.segments.splice(i, 1);      //power move right here, clears empty segments
            }
        }
        for(i = 0; i < this.segments.length; i++) {
            if(this.orientation % 4 == 0) {    //if east-west
                this.segments[i].pixelX = this.pixelX - 0.5 * CREASE_LENGTH + (2 * i + 1)/(2 * this.segments.length) * CREASE_LENGTH;
                this.segments[i].gridX = pixelToGrid(this.segments[i].pixelX);
            } else if(this.orientation % 4 == 2) {
                this.segments[i].pixelY = this.pixelY - 0.5 * CREASE_LENGTH + (2 * i + 1)/(2 * this.segments.length) * CREASE_LENGTH;
                this.segments[i].gridY = pixelToGrid(this.segments[i].pixelY);
            } else {
                console.log("Invalid orientation on one of the segments of one of the creases");
            }
        }
    }
}

function Segment(mother) {
    this.mother = mother;
    this.orientation = mother.orientation;
    this.gridX;
    this.gridY;
    if(mother.orientation % 4 == 0){
        this.gridY = mother.gridY;
        this.pixelY = gridToPixel(mother.gridY);
    } else if (mother.orientation % 4 == 2){
        this.gridX = mother.gridX;
        this.pixelX = gridToPixel(mother.gridX);
    } else {
        console.log("Invalid orientation on one of the creases");
    }
    this.pixelX;
    this.pixelY;
    
    this.occupant = null;
    this.isHoveredOver = false;
    this.isClicked = false;
    this.isClicked2 = false;
    this.appear = function(){   //must be done within the crease's drawing mode only
        var n = this.mother.segments.length;
        var displacement;
        if(this.orientation % 4 == 0) {
            displacement = this.pixelX - this.mother.pixelX;
        } else if(this.orientation % 4 == 2){
            displacement = -this.pixelY + this.mother.pixelY;  //only reason this is negative of the above one is because the coordinate system has posY going down and my angle system has posOctogree going counterclockwise
        } else {
            console.log("error");
        }
        if(this.isHoveredOver == true) {
            fill(255, 255, 210, 85);
            rect(displacement, 0, CREASE_LENGTH / n, CREASE_WIDTH);
        }
        if(this.isClicked == true) {
            fill(210, 255, 210, 100);
            rect(displacement, 0, CREASE_LENGTH / n, CREASE_WIDTH);
        }
    }
}

function coordIsInCrease(x, y, crease) {
    if(crease.orientation % 4 == 0) {
        if((abs(crease.pixelX - x) < CREASE_LENGTH / 2) && abs(crease.pixelY - y) < CREASE_WIDTH / 2 + 1) {
            return true;
        } else {
            return false;
        }
    } else if(crease.orientation % 4 == 2) {
        if((abs(crease.pixelY - y) < CREASE_LENGTH / 2) && abs(crease.pixelX - x) < CREASE_WIDTH / 2 + 1) {
            return true;
        } else {
            return false;
        }
    } else {
        console.log("Invalid crease: " + crease);
    }
}

function coordIsInAnyCrease(x, y) {
    var result = false;
    for(i = 0; i < creases.length; i++) {
        if(coordIsInCrease(x, y, creases[i])) {
            result = true;
        }
    }
    return result;
}

function createCreases() {
    creases[0] = new Crease(2.5, 1.5, 0);
    creases[1] = new Crease(3.5, 0.5, 2);
    creases[2] = new Crease(5.5, 0.5, 2);
    creases[3] = new Crease(7.5, 0.5, 2);
}

function blazeCreases() {
    for(i = 0; i < creases.length; i++) {
        creases[i].blaze();
    }
}

function whichSegment(crease, x, y) {
    var result;
    if(crease.orientation % 4 == 0) {
        result = Math.floor((mouseX - (crease.pixelX - 0.5 * CREASE_LENGTH)) * crease.segments.length / CREASE_LENGTH);
    } else if(crease.orientation % 4 == 2) {
        result = Math.floor((mouseY - (crease.pixelY - 0.5 * CREASE_LENGTH)) * crease.segments.length / CREASE_LENGTH);
    } else {
        console.log("error in orientation");
    }
    return result;
}