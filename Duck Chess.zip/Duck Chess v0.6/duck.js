/*facts about ducks:

can face only in cardinal directions
can turn 90 degrees
can move forward only

can kill forward only

gets killed from side
gets permakilled from rear
impervious from front

can get shot out of a cannon in any direction
can kill upon landing if facing forward with respect to direction of cannon shot(same facing as the cannon that shot it out)
*/

function Duck(gridX, gridY, team) {
    this.type = "duck";
    this.team = team;
    this.host = dataBoard[gridY][gridX];           //host is more general than dataBoard[this.gridY][this.gridX] bcz it can handle creases and infirmaries
    this.gridX = gridX;
    this.gridY = gridY;
    this.orientation = 0;
    
    this.inInfirmary = false;
    this.inCrease = false;
    
    this.appear = function() {
        var pixelX = gridToPixel(this.gridX);
        var pixelY = gridToPixel(this.gridY);
        
        push();
        translate(pixelX, pixelY);
        if(this.inCrease == true) {
            scale(0.4, 0.4);
        }
        rotate(octogree(this.orientation));
        
        fill(240, 240, 20);
        ellipse(0, 0, 80, 60);
        ellipse(25, 0, 40, 40);
        if(this.team == "blue") {
            fill(20, 20, 240);
        } else if(this.team == "red") {
            fill(240, 20, 20);
        } else {
            console.log("invalid team color: " + this.team)
        }
        ellipse(-18, 0, 40, 4);
        pop();
    }
    
    //update, occupy, appear!
    
    this.update = function() {  //only triggers if piece is being MOVED
        var override = false;
        if(twoSquaresSelected()) {         //regular movement and capture
            if(this.host.isClicked && validMove()) {
                if(selection.clicked2.thing instanceof Crease) {
                    selection.clicked2.thing.segments[selection.clicked2.thing.segments.length] = new Segment(selection.clicked2.thing); //adds a new Segment to segments array
                    this.host.occupant = null; //setting old square's occupant to null (square side)
                    this.host = selection.clicked2.thing.segments[selection.clicked2.thing.segments.length - 1]; //updating new host(piece side)
                    override = true;
                } else if(selection.clicked2.thing.occupant != null) { //If a piece is in its way and it's not heading to a creases
                    selection.clicked2.thing.occupant.kill();
                }
                if(!override) {
                    this.host.occupant = null; //setting old square's occupant to null (square side)
                    this.host = selection.clicked2.thing;              //updating new host (piece side)
                }
                if(this.host instanceof Crease || this.host instanceof Segment) {
                    this.inCrease = true;
                } else {
                    this.inCrease = false;
                }
                if(this.inInfirmary) {
                    this.inInfirmary = false;
                }
            }
        }
    }
    
    this.occupy = function() {
        this.host.occupant = this;   //quite self-evident
        this.gridX = this.host.gridX;
        this.gridY = this.host.gridY;
    }
    
    this.kill = function() {    //function for BEING killed
        this.host.occupant = null;
        this.host = infirmary[this.team];
        this.inInfirmary = true;
        infirmary[this.team].occupant = this;
        this.inCrease = false;
        console.log("piece killed");
    }
}