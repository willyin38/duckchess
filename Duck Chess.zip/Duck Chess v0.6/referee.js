
function validMove() {
    var square1 = selection.clicked.thing;
    var square2 = selection.clicked2.thing;
    var piece1 = selection.clicked.thing.occupant;
    var piece2 = selection.clicked2.thing.occupant;
    //direction of motion, from piece1's pov
    var piece1pov;
    //direction of being attacked, from piece2's pov
    var piece2pov;
    
    if(square1.occupant == null) {   //move cannot be valid if no piece is being moved
        return false;
    }
    
    if(square2.occupant != null && piece2.team == piece1.team) {    //can't land on same square as own teammate
        return false;
    }
    
    if(square1 instanceof Segment && square2 instanceof Crease) {   //can't hop from one crease to another
        return false;
    }
    
    
    if(square2 instanceof Crease) {   //If you're traveling to a crease that is 0.5 grid away, you're all good
        if(abs(square2.gridX - square1.gridX) == 0.5 && abs(square2.gridY - square1.gridY) == 0.5) {
            if(piece1.type == "ball") {
                return true;
            }
            if(piece1.type == "duck" && square1 instanceof BoardSquare) {
                if(square1.crease.e && piece1.orientation == 0 && square2.orientation % 4 == 2||
                   square1.crease.n && piece1.orientation == 2 && square2.orientation % 4 == 0||
                   square1.crease.w && piece1.orientation == 4 && square2.orientation % 4 == 2||
                   square1.crease.s && piece1.orientation == 6 && square2.orientation % 4 == 0) {
                    return true;
                }
                return false;
            }
        }
    }
    
    if(square2.terrainType == 0 || square2.terrainType == 2 || square2.terrainType == 3) {  //can't move to mountains or water or infirmaries
        return false;
    }
    
    if(square1.terrainType == 3) {
        if(!(square2 instanceof BoardSquare)){
            return false;
        }
        if(piece1.team == "blue" && square2.terrainType == 4) {
            return true;
        }
        if(piece1.team == "red" && square2.terrainType == 5) {
            return true;
        }
        return false;
    }
    
    if(abs(square1.gridX - square2.gridX) > 1 || abs(square1.gridY - square1.gridY) > 1) {  //can't move more than 1 square away in either direction
        return false;
    }
    
    piece1pov = ((radToOctogree(atan2(square2.gridY - square1.gridY, square2.gridX - square1.gridX)) - piece1.orientation) + 24) % 8;
    
    if(square2.occupant != null) {
        piece2pov = ((radToOctogree(atan2(square1.gridY - square2.gridY, square1.gridX - square2.gridX)) - piece2.orientation) + 24) % 8;
    }
    
    console.log(piece1pov);
    console.log(piece2pov);
    
    if(piece1.type == "duck" && !(square1 instanceof Segment)) {
        if(piece1pov != 0){  //ducks can't move in any direction but forward
            return false;
        }
    }
    
    if(piece1.type == "duck" && square1 instanceof Segment) {   //when in crease, ducks can only move forward-right or forward-left
        if(!(piece1pov == 1 || piece1pov == 7)) {
            return false;
        }
        if(piece1.orientation % 4 == square1.mother.orientation % 4) {
            return false;
        }
    }
    
    
    
    if(piece2 == null) {
        return true;
    }
    
    if(piece2.type == "duck") {
        if(piece2pov == 0) {
            return false;
        }
    }
    
    
    
    
    
    
        
        
    return true;
}