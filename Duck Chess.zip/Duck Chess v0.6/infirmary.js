//var infirmary = {
//    red: new BoardSquare(boardWidth - 0.5, boardHeight + 0.5),
//    blue: new BoardSquare(0.5, boardHeight + 0.5)
//}

function createInfirmaries() {
    dataBoard[boardHeight][0] = new BoardSquare(0.5, boardHeight + 0.5, 3);
    dataBoard[boardHeight][1] = new BoardSquare(boardWidth - 1.5, boardHeight + 0.5, 3);
    infirmary = {
        blue: dataBoard[boardHeight][0],
        red: dataBoard[boardHeight][1]
    };
}