/* facts about balls:

no facing direction (or all facing directions)
can move in any direction

can attack in any direction/facing

gets attacked in any direction/facing

can get shot out of a cannon
can kill upon landing provided valid target
*/

function Ball(gridX, gridY, team) {
    this.type = "ball";
    this.team = team;
    this.gridX = gridX;
    this.gridY = gridY;
    this.host = dataBoard[gridY][gridX];
    this.orientation = 0;
    
    this.inInfirmary = false;
    this.inCrease = false;
    
    this.appear = function() {
        var pixelX = gridToPixel(this.gridX);
        var pixelY = gridToPixel(this.gridY);
        push();
        translate(pixelX, pixelY);
        if(this.inCrease){
            scale(0.4, 0.4);
        }
        if(this.team == "blue") {
            fill(20, 20, 240);
        } else if(this.team == "red") {
            fill(240, 20, 20);
        } else {
            console.log("invalid team color: " + this.team)
        }
        ellipse(0, 0, 60, 60);
        pop();
    }
    
    this.update = function() {  //only triggers if piece is being MOVED
        var override = false;
        if(twoSquaresSelected()) {         //regular movement and capture
            if(this.host.isClicked && validMove()) {
                if(selection.clicked2.thing instanceof Crease) {
                    selection.clicked2.thing.segments[selection.clicked2.thing.segments.length] = new Segment(selection.clicked2.thing); //adds a new Segment to segments array
                    this.host.occupant = null; //setting old square's occupant to null (square side)
                    this.host = selection.clicked2.thing.segments[selection.clicked2.thing.segments.length - 1]; //updating new host(piece side)
                    override = true;
                } else if(selection.clicked2.thing.occupant != null) { //If a piece is in its way and it's not heading to a creases
                    selection.clicked2.thing.occupant.kill();
                }
                if(!override) {
                    this.host.occupant = null; //setting old square's occupant to null (square side)
                    this.host = selection.clicked2.thing;              //updating new host (piece side)
                }
                if(this.host instanceof Segment) {
                    this.inCrease = true;
                } else {
                    this.inCrease = false;
                }
                if(this.inInfirmary) {
                    this.inInfirmary = false;
                }
            }
        }
    }
    
    this.occupy = function() {
        this.host.occupant = this;   //quite self-evident
        this.gridX = this.host.gridX;
        this.gridY = this.host.gridY;
    }
    
    this.kill = function() {    //function for BEING killed
        this.host.occupant = null;
        this.host = infirmary[this.team];
        this.inInfirmary = true;
        infirmary[this.team].occupant = this;
        this.inCrease = false;
        console.log("piece killed");
    }
}