var ball1;
var ball2;
var ball3;
var ball4;
var duck1;

var creases = [];

var infirmary;

function setup() {
    
    createCanvas(CANVAS_WIDTH, CANVAS_HEIGHT);
    background(51);
    stroke(51);
    
    createBoard();
    createInfirmaries();
    createCreases();
    blazeCreases();
    
    spawnPieces();
    occupyAllPieces();
}

function draw() {
    background(51);
    hoverGlow();
    
    updateAllPieces();
    occupyAllPieces();
    
    creases[0].updateSegments();
    creases[1].updateSegments();
    creases[2].updateSegments();
    creases[3].updateSegments();
    infirmary.red.appear();
    infirmary.blue.appear();
    creases[0].appear();
    creases[1].appear();
    creases[2].appear();
    creases[3].appear();
    
    appearAllPieces();
    
    if(!nothingSelected(1) && !nothingSelected(2)) {
        selection.clicked.clear();
        selection.clicked2.clear();
    }
    
    
    fill(255, 255, 210);                          //coordinate debugging stuff
    if(selection.hovered.thing != null) {
        text(selection.hovered.thing.gridX + ", " + selection.hovered.thing.gridY, 80, 560);
    }
    if(selection.clicked.thing != null) {
        text(selection.clicked.thing.gridX + ", " + selection.clicked.thing.gridY, 500, 560);
    }
    if(selection.clicked2.thing != null) {
        text(selection.clicked2.thing.gridX + ", " + selection.clicked2.thing.gridY, 780, 560);
    }
    
}

function mouseClicked() {
    boardSelectionProcedure();
}

function keyPressed() {
    if(!nothingSelected(1)){
        var subject = selection.clicked.thing.occupant;
        selection.clicked.clear();
        if(subject != null) {
            if (keyCode == LEFT_ARROW) {
                subject.orientation = octoAdd(subject.orientation, 2);
                return false;
            } else if (keyCode == RIGHT_ARROW) {
                subject.orientation = octoAdd(subject.orientation, -2);
                return false;
            }
        }
    }
}

function maintenance() {
    // make sure no more than 1 square at a time has isClicked == true
}






