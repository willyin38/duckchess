//all about the selection of squares:
var selection = {
    hovered: {
        thing: null,
        clear: function(){if(this.thing != null){this.thing.isHoveredOver = false; this.thing = null;}},
        set: function(x){this.thing = x; this.thing.isHoveredOver = true;}
    },
    
    clicked: {
        thing: null,
        clear: function(){if(this.thing != null){this.thing.isClicked = false; this.thing = null;}},
        set: function(x){this.thing = x; this.thing.isClicked = true;}
    },
        
    clicked2: {
        thing: null,
        clear: function(){if(this.thing != null){this.thing.isClicked2 = false; this.thing = null;}},
        set: function(x){this.thing = x; this.thing.isClicked2 = true;}
    }
};

function boardSelectionProcedure(){
    if(coordIsOnBoard(mouseX, mouseY, "pixel") || coordIsInInfirmary(mouseX, mouseY, "red") || coordIsInInfirmary(mouseX, mouseY, "blue")) {
        if(nothingSelected(1)) {
            selection.clicked.set(selection.hovered.thing); //SETS HOVERED SQUARE TO CLICKED SQUARE
        } else {    //if something is selected
            if(selection.hovered.thing != selection.clicked.thing) { //is different square?
                selection.clicked2.set(selection.hovered.thing);
            } else { // what happens if you did actually click the same square again
                selection.clicked.clear(); //makes it so clicking on a clicked square causes an unclick
            }
        }
    } else {
        selection.clicked.clear(); //makes it so clicking off the board undoes your click
    }
}

function hoverGlow() {
    hoverRefresh();
    var mouseGridX = Math.round(pixelToGrid(mouseX));
    var mouseGridY = Math.round(pixelToGrid(mouseY));
    
    if(coordIsOnBoard(mouseGridX, mouseGridY, "grid")) {   // checking that mouse is actually in bounds - CRUCIAL
        
        if(!coordIsInAnyCrease(mouseX, mouseY)){  //if not hovering over board, but not any creases
            selection.hovered.set(dataBoard[mouseGridY][mouseGridX]); //hovering for regular board squares
        } else {
            for(i = 0; i < creases.length; i++) {
                if(coordIsInCrease(mouseX, mouseY, creases[i])) {  //hovering for creases  WORK TO DO: When nothingSelected(1), crease acts as segments, when !nothingSelected(1), crease acts as whole crease
                    if(!nothingSelected(1) || creases[i].segments.length == 0) {
                        selection.hovered.set(creases[i]);
                    } else {  //if nothingSelected
                        var j = whichSegment(creases[i], mouseX, mouseY);
                        selection.hovered.set(creases[i].segments[j]);    //this should direct it towards a Segment, need to do math to determine how
                    }
                }
            }
        }
    } else if(coordIsInInfirmary(mouseX, mouseY, "red")) {
        selection.hovered.set(infirmary.red);
    } else if(coordIsInInfirmary(mouseX, mouseY, "blue")) {
        selection.hovered.set(infirmary.blue);
    } else {
        selection.hovered.clear();
    }
}

//checks if nothing is selected according to selection obj. @param n = first or second click(takes 1 or 2)
function nothingSelected(n) {
    if(n == 1){
        if(selection.clicked.thing == null) {
        return true;
        }
    } else if(n == 2){
        if(selection.clicked2.thing == null) {
        return true;
        }
    } else {
        console.log('Invalad param "' + n + '" into nothingSelected function')
    }
}

function coordIsInInfirmary(x, y, col) {    //takes pixel inputs only
    var redX = gridToPixel(infirmary.red.gridX);  // in pixels, the x coord of the center of red infirmary
    var redY = gridToPixel(infirmary.red.gridY);
    var blueX = gridToPixel(infirmary.blue.gridX);
    var blueY = gridToPixel(infirmary.blue.gridY);
    
    if(abs(redX - x) <= GRID_SQUARE_WIDTH/2 && abs(redY - y) <= GRID_SQUARE_WIDTH/2 && col == "red") {
        return true;
    } else if(abs(blueX - x) <= GRID_SQUARE_WIDTH/2 && abs(blueY - y) <= GRID_SQUARE_WIDTH/2 && col == "blue") {
        return true;
    } else {
        return false;
    }
}

function coordIsOnBoard(x, y, coordinateSystem) {        //coordinateSystem can be "grid" or "pixel"
    var gridX;
    var gridY;
    if(coordinateSystem === "pixel") {
        gridX = Math.round(pixelToGrid(mouseX));
        gridY = Math.round(pixelToGrid(mouseY));
    } else if(coordinateSystem === "grid") {
        gridX = x;
        gridY = y;
    } else {
        console.log('Error: invalid param "' + coordinateSystem + '" was put into function coordIsOnBoard');
    }
    if((gridX >= 0 && gridX < boardWidth) && (gridY >= 0 && gridY < boardHeight)) {
        return true;
    } else {
        return false;
    }
}

function twoSquaresSelected() {
    if(!nothingSelected(1) && !nothingSelected(2)) {
        return true;
    } else {
        return false;
    }
}

//Unhovers everything
function hoverRefresh() {
    for(var y = 0; y < boardHeight; y++){
        for(var x = 0; x < boardWidth; x++){
            dataBoard[y][x].appear();
            dataBoard[y][x].isHoveredOver = false; //refreshes hover function; makes it so only 1 square is highlighted at a time
        }
    }
    for(var i = 0; i < creases.length; i++){
        creases[i].isHoveredOver = false;
        for(var j = 0; j < creases[i].segments.length; j++)
            creases[i].segments[j].isHoveredOver = false;
    }
}